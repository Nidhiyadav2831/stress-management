<!-- Add this div for notifications -->
<div id="notification" class="notification"></div>

<script src="assets/js/main.js"></script>
</body>
</html> 