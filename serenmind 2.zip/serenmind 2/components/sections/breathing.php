<!-- Breathing Section -->
<section id="breathing" class="section">
    <div class="max-w-3xl mx-auto">
        <h1 class="text-4xl font-extrabold text-center mb-6 bg-gradient-to-r from-indigo-500 to-blue-400 bg-clip-text text-transparent">Box Breathing Exercise</h1>
        <p class="text-center text-lg text-black mb-8 !text-black dark:!text-black">
            Box breathing is a simple but powerful technique for reducing stress and improving focus.<br>
            Follow the circle animation and breathe in a 4-4-4-4 pattern.
        </p>
        <div class="flex flex-col items-center gap-6 mt-8">
            <!-- Animated Circle -->
            <div id="boxBreathingCircle"
                class="flex items-center justify-center text-white font-extrabold text-2xl md:text-3xl transition-transform duration-1000 ease-in-out mb-8"
                style="width: 220px; height: 220px; background: linear-gradient(135deg, #36d1c4 0%, #5b6be6 100%); border-radius: 50%; box-shadow: 0 8px 32px rgba(44, 62, 80, 0.2);">
                Ready
            </div>
            <div class="text-center text-lg text-gray-400 mb-8">
                Inhale (4s) → Hold (4s) → Exhale (4s) → Hold (4s)
            </div>
            <button
                id="startBoxBreathing"
                class="w-80 py-4 text-2xl font-extrabold text-white rounded-xl shadow-xl
                       bg-gradient-to-r from-indigo-500 to-green-400
                       hover:from-indigo-600 hover:to-green-500
                       transition-all duration-300
                       focus:outline-none focus:ring-4 focus:ring-green-200"
                style="box-shadow: 0 8px 32px 0 rgba(44, 62, 80, 0.15);"
            >
                Start Exercise
            </button>
            <button
                id="stopBoxBreathing"
                class="w-80 py-4 text-2xl font-extrabold text-white rounded-xl shadow-xl
                       bg-red-500
                       hover:bg-red-600
                       transition-all duration-300
                       focus:outline-none focus:ring-4 focus:ring-red-200 hidden"
                style="box-shadow: 0 8px 32px 0 rgba(236, 72, 153, 0.15);"
            >
                Stop Exercise
            </button>
            <button
                onclick="showSection('meditation')"
                class="w-80 py-4 text-2xl font-extrabold text-white rounded-xl shadow-xl
                       bg-gradient-to-r from-purple-500 to-pink-400
                       hover:from-purple-600 hover:to-pink-500
                       transition-all duration-300
                       focus:outline-none focus:ring-4 focus:ring-pink-200"
                style="box-shadow: 0 8px 32px 0 rgba(236, 72, 153, 0.15);"
            >
                Next: Meditation →
            </button>
        </div>
    </div>
</section> 