<!-- Meditation Section -->
<section id="meditation" class="section">
    <div class="max-w-6xl mx-auto">
        <!-- Header Section -->
        <div class="flex justify-center items-center mb-16">
            <div class="text-center px-6 py-8 bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900 dark:to-pink-900 rounded-3xl shadow-lg transform hover:scale-105 transition-transform duration-300">
                <h1 class="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-blue-500 mb-4 drop-shadow-md hover:text-white transition-all duration-500">
                    🌟 Explore Meditation Videos 🌟
                </h1>
                <p class="text-lg md:text-xl text-gray-800 dark:text-gray-200 font-medium px-6 md:px-12 mb-8 opacity-80 hover:opacity-100 transition-opacity duration-300">
                    Discover peace and mindfulness through carefully curated meditation practices.
                    Take the first step towards a balanced and peaceful mind.
                </p>
            </div>
        </div>

        <!-- Beginner Section -->
        <div class="mb-16 px-4 py-12 bg-gradient-to-r from-blue-100 via-indigo-100 to-purple-100 dark:from-blue-900 dark:via-indigo-900 dark:to-purple-900 rounded-3xl">
            <h2 class="text-4xl font-bold text-blue-600 dark:text-blue-400 mb-6 text-center">✨ Beginner Level</h2>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="shadow-xl p-4 rounded-xl bg-white dark:bg-gray-700 hover:scale-105 transform transition-all duration-300">
                    <iframe class="w-full h-64 rounded-xl" src="https://www.youtube.com/embed/inpok4MKVLM" frameborder="0" allowfullscreen></iframe>
                    <p class="mt-4 text-lg text-teal-500 dark:text-teal-300 text-center font-medium">5-Minute Meditation You Can Do Anywhere</p>
                </div>
                <div class="shadow-xl p-4 rounded-xl bg-white dark:bg-gray-700 hover:scale-105 transform transition-all duration-300">
                    <iframe class="w-full h-64 rounded-xl" src="https://www.youtube.com/embed/wVSkYKj26qg" frameborder="0" allowfullscreen></iframe>
                    <p class="mt-4 text-lg text-purple-600 dark:text-purple-400 text-center font-medium">5 min Meditation for Clarity & Relaxation</p>
                </div>
                <div class="shadow-xl p-4 rounded-xl bg-white dark:bg-gray-700 hover:scale-105 transform transition-all duration-300">
                    <iframe class="w-full h-64 rounded-xl" src="https://www.youtube.com/embed/8_f7ltCNSAQ" frameborder="0" allowfullscreen></iframe>
                    <p class="mt-4 text-lg text-pink-500 dark:text-pink-300 text-center font-medium">Guided Morning Meditation</p>
                </div>
            </div>
        </div>

        <!-- Intermediate Section -->
        <div class="mb-16 px-4 py-12 bg-gradient-to-r from-purple-100 via-pink-100 to-red-100 dark:from-purple-900 dark:via-pink-900 dark:to-red-900 rounded-3xl">
            <h2 class="text-4xl font-bold text-indigo-600 dark:text-indigo-400 mb-6 text-center">🌿 Intermediate Level</h2>
            <div class="grid md:grid-cols-3 gap-8">
                <div class="shadow-xl p-4 rounded-xl bg-white dark:bg-gray-700 hover:scale-105 transform transition-all duration-300">
                    <iframe class="w-full h-64 rounded-xl" src="https://www.youtube.com/embed/pAEioF7FaWY" frameborder="0" allowfullscreen></iframe>
                    <p class="mt-4 text-lg text-teal-500 dark:text-teal-300 text-center font-medium">Guided Meditation for Inner Peace and Calm</p>
                </div>
                <div class="shadow-xl p-4 rounded-xl bg-white dark:bg-gray-700 hover:scale-105 transform transition-all duration-300">
                    <iframe class="w-full h-64 rounded-xl" src="https://www.youtube.com/embed/xO9q0ioUwGc" frameborder="0" allowfullscreen></iframe>
                    <p class="mt-4 text-lg text-orange-600 dark:text-orange-400 text-center font-medium">20min mindful breathing meditation</p>
                </div>
                <div class="shadow-xl p-4 rounded-xl bg-white dark:bg-gray-700 hover:scale-105 transform transition-all duration-300">
                    <iframe class="w-full h-64 rounded-xl" src="https://www.youtube.com/embed/w4tlGeSrcNw" frameborder="0" allowfullscreen></iframe>
                    <p class="mt-4 text-lg text-green-500 dark:text-green-300 text-center font-medium">Guided Meditation For Stress and Anxiety</p>
                </div>
            </div>
        </div>

        <!-- Advanced Section -->
        <div class="mb-16 px-4 py-12 bg-gradient-to-r from-green-100 via-teal-100 to-cyan-100 dark:from-green-900 dark:via-teal-900 dark:to-cyan-900 rounded-3xl">
            <h2 class="text-4xl font-bold text-red-600 dark:text-red-400 mb-6 text-center">🌺 Advanced Level</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-4xl mx-auto">
                <div class="shadow-xl p-6 rounded-xl bg-white dark:bg-gray-700 hover:scale-105 transform transition-all duration-300">
                    <iframe class="w-full h-72 rounded-xl" src="https://www.youtube.com/embed/309hAID38Rs" frameborder="0" allowfullscreen></iframe>
                    <p class="mt-6 text-xl text-pink-600 dark:text-pink-400 text-center font-medium">Advanced Breathing - Ultimate Relaxation Exercise</p>
                    <p class="mt-2 text-gray-600 dark:text-gray-300 text-center">Master the art of deep breathing for ultimate relaxation and stress relief.</p>
                </div>
                <div class="shadow-xl p-6 rounded-xl bg-white dark:bg-gray-700 hover:scale-105 transform transition-all duration-300">
                    <iframe class="w-full h-72 rounded-xl" src="https://www.youtube.com/embed/jrZ_LI9qCFM" frameborder="0" allowfullscreen></iframe>
                    <p class="mt-6 text-xl text-purple-500 dark:text-purple-300 text-center font-medium">Advanced Mindfulness Meditation</p>
                    <p class="mt-2 text-gray-600 dark:text-gray-300 text-center">Deep dive into mindfulness practices for enhanced focus and awareness.</p>
                </div>
            </div>
        </div>
       
        <!-- Next Button -->
        <div class="fixed bottom-4 right-4">
            <button onclick="showSection('music')" class="px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-lg hover:opacity-90 transition-opacity transform hover:scale-105 transition-transform duration-300 shadow-lg">
                Next: Music <i class="fas fa-arrow-right ml-2"></i>
            </button>
        </div>
    </div>
</section> 