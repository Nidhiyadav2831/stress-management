<!-- Landing Page Section -->
<section id="landing" class="section active min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
    <div class="container mx-auto px-4 py-16 text-center">
        <h1 class="text-5xl md:text-6xl font-bold mb-6 gradient-text">Welcome to SereneMind</h1>
        <p class="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-8">Your journey to mental wellness begins here</p>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto mt-12">
            <!-- Feature Card 1 -->
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform">
                <div class="text-4xl mb-4">🧘‍♀️</div>
                <h3 class="text-xl font-semibold mb-2">Meditation</h3>
                <p class="text-gray-600 dark:text-gray-300">Find your inner peace with guided meditation sessions</p>
            </div>
            
            <!-- Feature Card 2 -->
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform">
                <div class="text-4xl mb-4">🎵</div>
                <h3 class="text-xl font-semibold mb-2">Music Therapy</h3>
                <p class="text-gray-600 dark:text-gray-300">Soothing sounds to calm your mind and soul</p>
            </div>
            
            <!-- Feature Card 3 -->
            <div class="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg transform hover:scale-105 transition-transform">
                <div class="text-4xl mb-4">🎨</div>
                <h3 class="text-xl font-semibold mb-2">Art Therapy</h3>
                <p class="text-gray-600 dark:text-gray-300">Express yourself through drawing and creative activities</p>
            </div>
        </div>

        <?php if (is_logged_in()): ?>
            <!-- Logout Button -->
            <div class="mt-12">
                <button onclick="showSection('about')" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full transition-colors">
                    Explore Now
                </button>
            </div>
        <?php else: ?>
            <!-- Login Button -->
            <div class="mt-12">
                <button onclick="showSection('login')" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full transition-colors">
                    Get Started
                </button>
            </div>
        <?php endif; ?>
        
        
    </div>
</section> 