<!-- About Section -->
<section id="about" class="section">
    <div class="max-w-6xl mx-auto">
        <!-- Hero Section with Image -->
        <div class="text-center mb-16">
            <h1 class="text-5xl font-extrabold mb-6 relative group">
                <span class="inline-block text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-emerald-500 transform transition-all duration-500 hover:scale-110 hover:rotate-1 hover:skew-y-1">
                    Welcome to SereneMind
                </span>
                <span class="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-48 h-1 bg-gradient-to-r from-indigo-600 to-emerald-500 rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></span>
                <span class="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-48 h-1 bg-gradient-to-r from-emerald-500 to-indigo-600 rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-500 delay-100"></span>
            </h1>
            <p class="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto transform transition-all duration-300 hover:scale-105">
                Your personal sanctuary for mental wellness and emotional balance. Discover peace through our carefully curated tools and resources.
            </p>
        </div>

        <div class="flex flex-col md:flex-row items-center gap-8 mb-16">
            <div class="flex-1 grid grid-cols-2 gap-4">
                <img src="https://images.unsplash.com/photo-1552693673-1bf958298935?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80"
                     alt="Lotus Meditation" class="rounded-2xl shadow-2xl w-full h-[250px] object-cover transform hover:scale-105 transition-transform duration-300">
                <img src="https://images.unsplash.com/photo-1528319725582-ddc096101511?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80"
                     alt="Group Meditation" class="rounded-2xl shadow-2xl w-full h-[250px] object-cover transform hover:scale-105 transition-transform duration-300">
                <img src="https://images.unsplash.com/photo-1499209974431-9dddcece7f88?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80"
                     alt="Beach Meditation" class="rounded-2xl shadow-2xl w-full h-[250px] object-cover transform hover:scale-105 transition-transform duration-300">
                <img src="https://images.unsplash.com/photo-1516534775068-ba3e7458af70?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&h=500&q=80"
                     alt="Sunrise Yoga" class="rounded-2xl shadow-2xl w-full h-[250px] object-cover transform hover:scale-105 transition-transform duration-300">
            </div>
            <div class="flex-1 text-center md:text-left space-y-6">
                <div class="relative group">
                    <h2 class="text-5xl font-extrabold mb-2 bg-gradient-to-r from-indigo-600 to-emerald-500 bg-clip-text text-transparent animate-gradient transform transition-all duration-500 hover:scale-105">
                        Your Journey to Peace
                    </h2>
                    <div class="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-indigo-600 via-purple-500 to-pink-500 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></div>
                    <div class="absolute -bottom-2 left-0 w-full h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-700 delay-100"></div>
                </div>
                <p class="text-xl leading-relaxed text-gray-600 dark:text-gray-300">
                    <span class="word-hover">Begin</span>
                    <span class="word-hover">your</span>
                    <span class="word-hover">path</span>
                    <span class="word-hover">to</span>
                    <span class="word-hover">inner</span>
                    <span class="word-hover">peace</span>
                    <span class="word-hover">and</span>
                    <span class="word-hover">mindfulness</span>
                    <span class="word-hover">with</span>
                    <span class="word-hover">our</span>
                    <span class="word-hover">comprehensive</span>
                    <span class="word-hover">wellness</span>
                    <span class="word-hover">tools</span>
                    <span class="word-hover">and</span>
                    <span class="word-hover">resources.</span>
                </p>
            </div>
        </div>

        <!-- Mission and Vision -->
        <div class="grid md:grid-cols-2 gap-8 mb-16">
            <div class="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900 dark:to-indigo-900 p-8 rounded-2xl shadow-xl transform hover:scale-105 transition-all duration-300">
                <h2 class="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-4">Our Mission</h2>
                <p class="text-gray-700 dark:text-gray-300 text-lg leading-relaxed">
                    To provide accessible tools and resources for mental wellness, helping individuals achieve inner peace and emotional balance in their daily lives.
                </p>
            </div>
            <div class="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900 dark:to-pink-900 p-8 rounded-2xl shadow-xl transform hover:scale-105 transition-all duration-300">
                <h2 class="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-4">Our Vision</h2>
                <p class="text-gray-700 dark:text-gray-300 text-lg leading-relaxed">
                    To create a world where mental wellness is prioritized and accessible to everyone, fostering a community of mindfulness and emotional well-being.
                </p>
            </div>
        </div>

        <!-- Features Grid -->
        <div class="grid md:grid-cols-3 gap-8 mb-16">
            <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300">
                <div class="text-4xl text-blue-500 dark:text-blue-400 mb-4">
                    <i class="fas fa-spa"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 dark:text-gray-200 mb-2">Guided Meditation</h3>
                <p class="text-gray-600 dark:text-gray-400">
                    Access a variety of meditation sessions tailored to your needs and experience level.
                </p>
            </div>
            <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300">
                <div class="text-4xl text-green-500 dark:text-green-400 mb-4">
                    <i class="fas fa-wind"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 dark:text-gray-200 mb-2">Breathing Exercises</h3>
                <p class="text-gray-600 dark:text-gray-400">
                    Learn and practice breathing techniques for stress relief and relaxation.
                </p>
            </div>
            <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300">
                <div class="text-4xl text-purple-500 dark:text-purple-400 mb-4">
                    <i class="fas fa-music"></i>
                </div>
                <h3 class="text-xl font-bold text-gray-800 dark:text-gray-200 mb-2">Relaxing Music</h3>
                <p class="text-gray-600 dark:text-gray-400">
                    Enjoy curated playlists designed to enhance your meditation and relaxation experience.
                </p>
            </div>
        </div>

        <!-- Team Section -->
        <div class="mb-16">
            <div class="text-center mb-12">
                <h2 class="text-4xl font-bold mb-6 relative group">
                    <span class="inline-block text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-emerald-500 transform transition-all duration-500 hover:scale-110 hover:rotate-1 hover:skew-y-1">
                        Meet Our Expert Team
                    </span>
                    <span class="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-gradient-to-r from-indigo-600 to-emerald-500 rounded-full scale-x-0 group-hover:scale-x-100 transition-transform duration-500"></span>
                </h2>
                <p class="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8">
                    Our team of mental wellness experts brings together decades of experience in psychology,
                    mindfulness, and digital wellness. Each member is committed to helping you achieve your mental health goals.
                </p>
            </div>

            <div class="grid grid-cols-4 gap-8">
                <!-- Team Member 1 -->
                <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300 group">
                    <div class="relative overflow-hidden rounded-full w-32 h-32 mx-auto mb-4">
                        <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
                             alt="Dr. Sarah Mitchell" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110">
                        <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                    <h3 class="text-xl font-bold text-center text-teal-700 dark:text-teal-400 group-hover:text-indigo-600 transition-colors">Dr. Sarah Mitchell</h3>
                    <p class="text-center text-gray-600 dark:text-gray-400 font-medium">Clinical Psychologist</p>
                    <p class="text-center text-sm text-gray-500 dark:text-gray-400 mt-2">Specialized in Cognitive Behavioral Therapy and Anxiety Management</p>
                    <div class="mt-4 flex justify-center space-x-4">
                        <a href="#" class="text-blue-500 hover:text-blue-700 transform hover:scale-110 transition-transform"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="text-pink-500 hover:text-pink-700 transform hover:scale-110 transition-transform"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-blue-400 hover:text-blue-600 transform hover:scale-110 transition-transform"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>

                <!-- Team Member 2 -->
                <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300 group">
                    <div class="relative overflow-hidden rounded-full w-32 h-32 mx-auto mb-4">
                        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
                             alt="James Wilson" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110">
                        <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                    <h3 class="text-xl font-bold text-center text-teal-700 dark:text-teal-400 group-hover:text-indigo-600 transition-colors">James Wilson</h3>
                    <p class="text-center text-gray-600 dark:text-gray-400 font-medium">Mindfulness Coach</p>
                    <p class="text-center text-sm text-gray-500 dark:text-gray-400 mt-2">Expert in Meditation Techniques and Stress Reduction</p>
                    <div class="mt-4 flex justify-center space-x-4">
                        <a href="#" class="text-blue-500 hover:text-blue-700 transform hover:scale-110 transition-transform"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="text-pink-500 hover:text-pink-700 transform hover:scale-110 transition-transform"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-blue-400 hover:text-blue-600 transform hover:scale-110 transition-transform"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>

                <!-- Team Member 3 -->
                <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300 group">
                    <div class="relative overflow-hidden rounded-full w-32 h-32 mx-auto mb-4">
                        <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
                             alt="Dr. Emily Chen" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110">
                        <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                    <h3 class="text-xl font-bold text-center text-teal-700 dark:text-teal-400 group-hover:text-indigo-600 transition-colors">Dr. Emily Chen</h3>
                    <p class="text-center text-gray-600 dark:text-gray-400 font-medium">Sleep Specialist</p>
                    <p class="text-center text-sm text-gray-500 dark:text-gray-400 mt-2">Expert in Sleep Disorders and Relaxation Techniques</p>
                    <div class="mt-4 flex justify-center space-x-4">
                        <a href="#" class="text-blue-500 hover:text-blue-700 transform hover:scale-110 transition-transform"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="text-pink-500 hover:text-pink-700 transform hover:scale-110 transition-transform"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-blue-400 hover:text-blue-600 transform hover:scale-110 transition-transform"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>

                <!-- Team Member 4 -->
                <div class="bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300 group">
                    <div class="relative overflow-hidden rounded-full w-32 h-32 mx-auto mb-4">
                        <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
                             alt="Michael Rodriguez" class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110">
                        <div class="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    </div>
                    <h3 class="text-xl font-bold text-center text-teal-700 dark:text-teal-400 group-hover:text-indigo-600 transition-colors">Michael Rodriguez</h3>
                    <p class="text-center text-gray-600 dark:text-gray-400 font-medium">Wellness Coach</p>
                    <p class="text-center text-sm text-gray-500 dark:text-gray-400 mt-2">Specialized in Holistic Health and Lifestyle Management</p>
                    <div class="mt-4 flex justify-center space-x-4">
                        <a href="#" class="text-blue-500 hover:text-blue-700 transform hover:scale-110 transition-transform"><i class="fab fa-linkedin"></i></a>
                        <a href="#" class="text-pink-500 hover:text-pink-700 transform hover:scale-110 transition-transform"><i class="fab fa-instagram"></i></a>
                        <a href="#" class="text-blue-400 hover:text-blue-600 transform hover:scale-110 transition-transform"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="flex justify-center gap-8 py-10">
  <!-- Instagram -->
  <a href="https://www.instagram.com" target="_blank" class="transform transition-transform duration-300 hover:scale-110">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="text-gradient bg-gradient-to-r from-pink-500 via-purple-500 to-yellow-500 fill-current">
      <path d="M12 2.163c3.128 0 3.494.011 4.724.068 1.17.057 1.897.25 2.348.424.518.165.971.38 1.406.814.434.435.648.888.814 1.406.174.451.367 1.178.424 2.348.057 1.23.068 1.596.068 4.724s-.011 3.494-.068 4.724c-.057 1.17-.25 1.897-.424 2.348-.165.518-.38.971-.814 1.406-.435.434-.888.648-1.406.814-.451.174-1.178.367-2.348.424-1.23.057-1.596.068-4.724.068s-3.494-.011-4.724-.068c-1.17-.057-1.897-.25-2.348-.424-.518-.165-.971-.38-1.406-.814-.434-.435-.648-.888-.814-1.406-.174-.451-.367-1.178-.424-2.348-.057-1.23-.068-1.596-.068-4.724s.011-3.494.068-4.724c.057-1.17.25-1.897.424-2.348.165-.518.38-.971.814-1.406.435-.434.888-.648 1.406-.814.451-.174 1.178-.367 2.348-.424 1.23-.057 1.596-.068 4.724-.068zM12 5.847a6.153 6.153 0 1 0 0 12.307 6.153 6.153 0 0 0 0-12.307zm0 10.615a4.462 4.462 0 1 1 0-8.924 4.462 4.462 0 0 1 0 8.924zM17.317 6.683a1.05 1.05 0 1 0 0-2.1 1.05 1.05 0 0 0 0 2.1z"/>
    </svg>
  </a>

  <!-- Facebook -->
  <a href="https://www.facebook.com" target="_blank" class="transform transition-transform duration-300 hover:scale-110">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="text-blue-600 fill-current">
      <path d="M22.675 0h-21.35C.898 0 0 .898 0 2.025v19.95c0 1.126.898 2.025 2.025 2.025h11.512v-9.267h-3.124v-3.622h3.124v-2.664c0-3.092 1.835-4.803 4.667-4.803 1.342 0 2.728.099 3.07.142v3.62h-2.036c-1.596 0-2.074.798-2.074 2.015v2.42h4.136l-.531 3.622h-3.605v9.267h7.084c1.126 0 2.025-.898 2.025-2.025V2.025c0-1.126-.898-2.025-2.025-2.025z"/>
    </svg>
  </a>

  <!-- Twitter -->
  <a href="https://www.twitter.com" target="_blank" class="transform transition-transform duration-300 hover:scale-110">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="text-blue-400 fill-current">
      <path d="M23.643 4.937c-.885.392-1.83.656-2.827.775 1.016-.61 1.796-1.574 2.165-2.722-.951.564-2.005.974-3.127 1.191-.897-.957-2.171-1.549-3.584-1.549-2.717 0-4.914 2.188-4.914 4.894 0 .384.044.758.127 1.118-4.088-.206-7.708-2.182-10.126-5.195-.422.728-.663 1.577-.663 2.479 0 1.71.868 3.215 2.189 4.094-.807-.025-1.567-.249-2.229-.621v.062c0 2.397 1.693 4.399 3.946 4.851-.413.111-.849.171-1.291.171-.314 0-.623-.031-.926-.088.624 1.949 2.444 3.374 4.602 3.415-1.684 1.319-3.803 2.103-6.112 2.103-.396 0-.787-.023-1.175-.069 2.176 1.398 4.773 2.212 7.559 2.212 9.06 0 14.025-7.505 14.025-14.004 0-.214-.007-.428-.02-.64.962-.692 1.798-1.56 2.46-2.549z"/>
    </svg>
  </a>

  <!-- LinkedIn -->
  <a href="https://www.linkedin.com" target="_blank" class="transform transition-transform duration-300 hover:scale-110">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" class="text-blue-700 fill-current">
      <path d="M22.225 0h-20.45c-.424 0-.774.344-.774.774v22.452c0 .426.35.774.774.774h20.45c.428 0 .774-.348.774-.774v-22.452c0-.43-.346-.774-.774-.774zM7.186 19.226h-3.89v-11.46h3.89v11.46zM5.125 6.368c-1.252 0-2.26-1.008-2.26-2.258 0-1.251 1.008-2.258 2.26-2.258s2.26 1.008 2.26 2.258c0 1.25-1.008 2.258-2.26 2.258zm14.087 12.858h-3.89v-5.891c0-1.4-.5-2.357-1.762-2.357-1.009 0-1.611.671-1.874 1.318-.095.235-.119.562-.119.892v6.238h-3.89v-11.46h3.89v1.5c.524-.811 1.402-1.921 3.415-1.921 2.493 0 4.575 1.607 4.575 5.057v6.824z"/>
    </svg>
  </a>
</div>

</section> 